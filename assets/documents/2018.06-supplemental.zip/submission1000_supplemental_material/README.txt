# Contents

This folder contains our paper's supplemental material in a companion website. Here, 
we describe how to view the website using a local http server. The site is also online
at http://vdl.sci.utah.edu/VisualizationCreativityWorkshops/

# Serving the website with python2

We can serve the website with a python http server. The server must be started
from the 'site' directory. For example: 

	~/submission1000_supplemental_material$ ls
		README  site/
	~/submission1000_supplemental_material$ cd site
	~/submission1000_supplemental_material/site$ ls
		index.html  VisualizationCreativityWorkshops/
	~/submission1000_supplemental_material/site$ python -m SimpleHTTPServer 8000

Then, view the website at:

	http://localhost:8000/VisualizationCreativityWorkshops

# Serving the website with python3
		
If using python3, follow the directions above but start the server with:

	~/submission1000_supplemental_material/site$ python -m http.server 8000