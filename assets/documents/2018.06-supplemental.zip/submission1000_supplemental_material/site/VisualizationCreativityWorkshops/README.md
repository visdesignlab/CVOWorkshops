# Visualization Creativity Workshops

Supplemental Material for the paper "A Framework for Creativity Workshops in Applied Visualization Research" submitted to IEEE InfoVis, 2018.

## Development

Built using Jekyll + GitHub Pages. Follow the directions [here](https://help.github.com/enterprise/2.12/user/articles/setting-up-your-github-pages-site-locally-with-jekyll/) to setup a development environment.

If developing locally, the main page will be served at http://127.0.0.1:4000/VisualizationCreativityWorkshops/
